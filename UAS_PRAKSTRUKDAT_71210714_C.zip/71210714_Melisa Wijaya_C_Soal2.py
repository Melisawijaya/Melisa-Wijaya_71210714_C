class Node:
    def __init__(self,data,priority) -> None:
        self._data = data
        self._priority = priority
        self._list = [self._data,self._priority]
        self._next = None
        self._prev = None

class PQSTugas:
    def __init__(self) -> None:
        self._head = None
        self._tail = None
        self._size = 0

    def isEmpty(self) -> bool:
        return self._size == 0

    def printAll(self) -> None:
        print("=== Prioritas : Tugas ===")
        if self.isEmpty() == False:
            bantu = self._head
            while(bantu != self._tail._next):
                print(bantu._data, end = "")
                bantu = bantu._next
            print()
        else:
            print("Tidak ada tugas")

    def _addHead(self, newNode) -> None:
        baru = Node(newNode)
        if self.isEmpty() == True:
            self._head = baru
            self._tail = baru
            self._head._next = None
            self._head._prev = None
            self._tail._next = None
            self._tail._prev = None
        else:
            baru._next = self._head
            self._head._prev = baru
            self._head = baru
            self._size += 1

    # def _addTail(self, newNode) -> None:
    #     #isi kode anda
    #     pass

    # def _addMiddle(self, newNode) -> None:
    #     #isi kode anda
    #     pass

    def add(self, data, priority) -> None:
        baru = Node(data, priority)
        if self.isEmpty():
            self._head = baru
            self._tail = baru
            self._head._next = None
            self._head._prev = None
            self._tail._next = None
            self._tail._prev = None
        else:
            baru._next = self._head
            self._head._prev = baru
            self._head = baru
            self._size += 1
        

    def remove(self) -> None:
        #isi kode anda
         pass

    def removePriority(self, priority) -> None:
        #isi kode anda
        pass
if __name__ == "__main__":
 tugasKu = PQSTugas()
 tugasKu.add("StrukDat",1)
 tugasKu.add("Menyapu", 5)
 tugasKu.add("Cuci Baju", 4)
 tugasKu.add("Beli Alat Tulis", 3)
 tugasKu.add("Cuci Sepatu", 4)
 tugasKu.printAll()
#  tugasKu.remove()
#  tugasKu.printAll()
#  tugasKu.removePriority(2)
#  tugasKu.removePriority(4)
#  tugasKu.printtAll()

