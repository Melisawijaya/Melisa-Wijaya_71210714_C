class NodePelanggan:
    def __init__(self, namaPelanggan):
        self._namaPelanggan = namaPelanggan

    def getNamaPelanggan(self):
        return self._namaPelanggan

class WarungMakan:
    DEFAULT_CAPACITY = 5
    def __init__(self): #tidak boleh mengganti / menambah metode init
        self._data = [None] * WarungMakan.DEFAULT_CAPACITY
        self._size = 0
        self._front = 0

    def __len__(self):
        return self._size

    def is_empty(self):
        return self._size == 0

    def dequeue(self): #menghapus data paling depan, dan memajukan urutan data yang dibelangkangnya
        data = self._data[self._front]
        self._data[self._front] = None
        self._front = (self._front + 1) % len(self._data)
        self._size -= 1
        print(f"### Pelanggan {data} Selesai Membayar ###")

    def enqueue(self, namaPelanggan): #menambah data ke list
        if self._size == len(self._data):
            self.resizeBy3(2 * len(self._data))
        new = (self._front + self._size) % len(self._data)
        self._data[new] = namaPelanggan
        self._size += 1

    def resizeBy3(self, cap): #menambah ukuran queue sebesar 3
        print("### Melakukan Rezise 3 ### \n")
        data_lama = self._data
        self._data = [None] * cap
        # self._capacity = WarungMakan.DEFAULT_CAPACITY * cap
        first = self._front
        for i in range(self._size):
            self._data[i] = data_lama[first]
            first = (1 + first) % len(data_lama)
        self._front = 0

    def printAll(self):
        # if len(self._data) > WarungMakan.DEFAULT_CAPACITY:
        #     self.resizeBy3(2 * len(self._data))
        print("\n=== WarungMakan ===")
        c = len(self._data)-1
        n = 1
        for i in range (0, WarungMakan.DEFAULT_CAPACITY):
            if i <= c:
                print(n, ".", self._data[i], end = " ")
                print()
            else:
                print(n,". Kosong")
            n += 1

    # def printAll(self):
    #     print("\n=== WarungMakan ===")
    #     for i in range(len(self._data)):
    #         if self._data[i] != None:
    #             print(i+1,end=". ")
    #             print(self._data[i])
    #         else:
    #             print(i+1,end=". ")
    #             print("Kosong")

# test case program
wm = WarungMakan()
wm.enqueue("Pelanggan A")
wm.enqueue("Pelanggan B")
wm.enqueue("Pelanggan C")
wm.enqueue("Pelanggan D")
wm.enqueue("Pelanggan E")
wm.printAll()
wm.enqueue("Pelanggan F")
# wm.enqueue("Pelanggan G")
# wm.printAll()
# wm.dequeue()
# wm.dequeue()
# wm.dequeue()
# wm.printAll()